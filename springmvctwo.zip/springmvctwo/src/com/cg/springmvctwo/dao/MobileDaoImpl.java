package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvctwo.dto.Cart;
import com.cg.springmvctwo.dto.Order;


@Repository("dao")
public class MobileDaoImpl implements IMobileDao{
	
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Cart> getAllDetails() {
		// TODO Auto-generated method stub
		
		Query queryGet=em.createQuery("FROM Cart");
		List<Cart> myList=queryGet.getResultList();
		return myList;
	}

	@Override
	public void insertOrderDetails(Order orderdetails) {
		em.persist(orderdetails);
		em.flush();
	}
}
